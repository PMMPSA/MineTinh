# FactionsPro - Modded
###### Credit and thanks to TETHERED for writing this plugin, and various other teams who contributed other parts of the code. Let me know if you'd like credit, I don't know who you are...


Added ClaimWorlds array to config to define worlds where /f claim is allowed
Other minor changes
