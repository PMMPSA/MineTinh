<?php

namespace LvPickaxe;

use pocketmine\scheduler\Task;
use pocketmine\Server;
use pocketmine\Player;
use LvPickaxe\Main;

class PopupTask extends Task{
	public function __construct(Main $plugin, Player $player){
		$this->plugin = $plugin;
		$this->player = $player;
		}
	public function onRun($currentTick){
		foreach($this->plugin->getServer()->getOnlinePlayers() as $player){
			$i = $player->getInventory()->getItemInHand();
			$hand = $i->getCustomName();
			$it = explode(" ", $hand);
			$damage = $i->getDamage();
				if($it[0] == "§r§l§c→§9"){
					if($damage > 30){
				  		$i->setDamage(0);
			    		$player->getInventory()->setItemInHand($i);
                 	$player->sendMessage("§l§eCúp của bạn đã được sửa chữa!");
					}
          	   $equal = ($this->plugin->getExp($player)/$this->plugin->getNextExp($player))*100;
					$player->sendPopup("§e⎳§c CÚP: §9Ｔ§aｅｒｒｉａｌ'ｓ§6 ❖\n§e→§6 Kinh nghiệm:§b ".round($equal, 2)."%§f |§e Trình độ:§c ".$level);
				} else{
					$this->plugin->getServer()->getScheduler()->cancelTask($this->getTaskId());
				}
			}
		}
	}