<?php

namespace LvPickaxe;

use LvPickaxe\PopupTask;
use pocketmine\Player;
use pocketmine\Server;
use pocketmine\command\CommandSender;
use pocketmine\command\Command;
use pocketmine\utils\Config;
use pocketmine\plugin\PluginBase;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\event\player\PlayerItemHeldEvent;
use pocketmine\event\block\BlockBreakEvent;
use pocketmine\item\Item;
use pocketmine\item\enchantment\Enchantment;

class Main extends PluginBase implements Listener{
	
	 const CONFIG_VERSION = 2.14;
    const AUTHORS = K27;
	
    public function onLoad(){
         $this->getLogger()->info("Loading...");
      if(!file_exists($this->getDataFolder()."level/")){
         @mkdir($this->getDataFolder()."level/");
         }
      if(!file_exists($this->getDataFolder()."broke/")){
         @mkdir($this->getDataFolder()."broke/");
          }
      }
    public function onEnable(){
      $this->getServer()->getPluginManager()->registerEvents($this, $this);
      $this->level = new Config($this->getDataFolder()."level/"."players.yml", Config::YAML);
      $this->break = new Config($this->getDataFolder()."broke/"."players.yml", Config::YAML);
      $this->saveDefaultConfig();
      $this->money = $this->getServer()->getPluginManager()->getPlugin("EconomyAPI");
      $this->enchant = $this->getServer()->getPluginManager()->getPlugin("PTKCustomEnchants");
      }
    public function onJoin(PlayerJoinEvent $event){
      $player = $event->getPlayer();
      			if(!$this->level->exists($player->getName())){
                $this->level->set($player->getName(), ["Level" => 1, "Recent" => 0, "Max" => 120]);
                $this->level->save();
                $item = Item::get(274, 0, 1);
                $item->setCustomName($this->getNamePickaxe($player));
                $item->setLore(array($this->getLorePickaxe($player)));
                $player->getInventory()->addItem($item);
                $this->getLogger()->critical($player->getName()." Đã được tạo thông tin cá nhân!");
               }
            if(!$this->break->exists($player->getName())){
                $this->break->set($player->getName(), 0);
                $this->break->save();
               }
    	 }
    public function getLevel($player){
       if($player instanceof Player){
          $player = $player->getName();
          }
         return $this->level->get($player)["Level"];
       }
   public function setLevel($player, $level){
			if($player instanceof Player){
				$player = $player->getName();
				}
		 $nextexp = ($this->getLevel($player)+1)*70;
		 $this->level->set($player, ["Level" => $level, "Recent" => 0, "Max" => $nextexp]);
		 $this->level->save();
			}
   public function setNextExp($player, $exp){
        if($player instanceof Player){
           $player = $player->getName();
           }
        $exp = $this->level->get($player)["Max"] + $exp;
        $this->level->set($player, ["Level" => $this->level->get($player)["Level"], "Recent" => $this->level->get($player)["Recent"], "Max" => $exp]);
        $this->level->save();
        }
   public function getExp($player){
	    if($player instanceof Player){
		     $player = $player->getName();
		        }
		     return $this->level->get($player)["Recent"];
        }
   public function getNextExp($player){
	    if($player instanceof Player){
		     $player = $player->getName();
		     }
		   return $this->level->get($player)["Max"];
		 }
	public function addExp($player, $exp){
		 if($player instanceof Player){
			  $player = $player->getName();
					}
			 $this->level->set($player, ["Level" => $this->level->get($player)["Level"], "Recent" => $this->level->get($player)["Recent"] + $exp, "Max" => $this->getNextExp($player)]);
			 $this->level->save();
			}
	public function onFinder(){
		if($this->getDescription()->getVersion() !== self::CONFIG_VERSION or $this->getDescription()->getAuthors() !== self::AUTHORS){
			$this->getLogger()->error("Xin lỗi người dùng Plugins Lv.Pickaxe!\nPhiên bản Plugins hoặc tên lập trình viên bị thay đổi bạn có thể chỉnh sửa lại, hoặc tải lại Plugins này.\nCảnh báo: Plugins sẽ không hoạt động nếu bạn cứ để yên plugin.yml");
			$this->getPluginLoader()->disablePlugin($this);
			}
		}
	public function getNamePickaxe($player){
		if($player instanceof Player){
			$player = $player->getName();
			}
		$name = "§r§l§c→§9 Ｔ§aｅｒｒｉａｌ'ｓ§6 ❖§b Lv:§4 ".$this->level->get($player)["Level"]."§6 ❖§e Player:§9 ".$player;
		return $name;
		}
	public function getLorePickaxe($player){
		if($player instanceof Player){
			$player = $player->getName();
			}
		if($this->level->get($player)["Level"] >= 1 && $this->level->get($player)["Level"] < 3){
		    $lore = "\n§r§l§b✎§e Chiếc cúp này được rèn luyện từ\nlòng§c Kiên Nhẫn§e của người chơi§9 Terrial's.\n§4❖§6 Ngươi đã triệu hồi ta, thế ngươi đã sẵn sàng chưa?\n\n§9→§b Chủ nhân:§a ".$player."\n§9→§e Trình độ: §c".$this->level->get($player)["Level"];
	      } elseif($this->level->get($player)["Level"] >= 3 && $this->level->get($player)["Level"] < 20){
			$lore = "\n§r§l§b✎§e Chiếc cúp này được rèn luyện từ\nlòng§c Kiên Nhẫn§e của người chơi§9 Terrial's.\n§4❖§6 Ngươi có tài đấy, nhưng thế chưa đủ đâu!\n§9→§b Chủ nhân:§a ".$player."\n§9→§e Trình độ: §c".$this->level->get($player)["Level"];
		                } elseif($this->level->get($player)["Level"] >= 20){
											$lore = "\n§r§l§b✎§e Chiếc cúp đã được tinh hoa của sự§c Kiên Nhẫn\n§erèn bén, quả thật rất đáng ngưỡng mộ!\n§4❖§6 Ngươi quả một nhân tài có trình\nđộ, sử dụng ta! Nhưng chưa dừng lại tại đây đâu.\n\n§9→§b Chủ nhân:§a ".$player."\n§9→§e Trình độ: §c".$this->level->get($player)["Level"];
											}
			return $lore;
 	}
	public function onHeld(PlayerItemHeldEvent $event){
		$task = new PopupTask($this, $event->getPlayer());
		       $this->task[$event->getPlayer()->getId()] = $task;
	   $this->getServer()->getScheduler()->scheduleRepeatingTask($task, 1);
	   $player = $event->getPlayer();
	   $item = $player->getInventory()->getItemInHand();
			if(isset($this->need[$player->getName()])){
				$item->setCustomName($this->getNamePickaxe($player));
				$item->setLore(array($this->getLorePickaxe($player)));
				if($this->getLevel($player) == 3){
					$item = Item::get(257, 0, 1);
				   $item->setCustomName($this->getNamePickaxe($player));
			    	$item->setLore(array($this->getLorePickaxe($player)));
				   $player->sendTitle("§l§7Iron Pickaxe!", "§l§6Chiếc cúp của bạn đã được luyện bằng§b Sắt!", 100, 100);
					} elseif($this->getLevel($player) == 20){
						$item = Item::get(278, 0, 1);
					   $item->setCustomName($this->getNamePickaxe($player));
			       	$item->setLore(array($this->getLorePickaxe($player)));
				      $player->sendTitle("§l§bDiamond Pickaxe!", "§l§6Chiếc cúp của bạn đã được luyện bằng§e Kim cương!", 100, 100);
						}
						if(in_array($this->getLevel($player), array(2, 4, 6, 8, 10, 12, 14, 16, 18, 20, 22, 24, 26, 28, 30, 32, 34, 36, 38, 40, 42, 44, 46, 48, 50, 52, 54, 56, 58, 60))){
							$enchant = Enchantment::getEnchantment(17)->setLevel($this->getLevel($player)/3);
							$item->addEnchantment($enchant);
							#
							} elseif(in_array($this->getLevel($player), array(3, 5, 7, 9, 11, 13, 15, 17, 19, 21, 23, 25, 27, 29, 31, 33, 35, 37, 39, 41, 43, 45, 47, 49, 51, 53, 55, 57, 59, 61))){
								$enchant = Enchantment::getEnchantment(18)->setLevel($this->getLevel($player)/2);
								$item->addEnchantment($enchant);
								#
								}
								if(in_array($this->getLevel($player), array(10, 20, 30, 40, 50))){
									$this->enchant->addEnchantment($item, "Haste", $this->getLevel($player)/10);
									#
									}
						$player->getInventory()->setItemInHand($item);
							unset($this->need[$player->getName()]);
				}
	}
	public function onBreak(BlockBreakEvent $event){
		$player = $event->getPlayer();
		$item = $player->getInventory()->getItemInHand();
		$icn = $item->getCustomName();
		$pas = explode(" ", $icn);
		if($pas[0] == "§r§l§c→§9"){
			if(!in_array($player->getName(), explode(" ", $icn))){
				$event->setCancelled(true);
				#
					}
				}
		if(!$event->isCancelled()){
			if($pas[0] == "§r§l§c→§9"){
				$this->break->set($player->getName(), $this->break->get($player->getName()) + 1);
				$this->break->save();
				 $block = $event->getBlock();
					switch($block->getId()){
						     case "1":
						     $this->addExp($player, 2);
						     break;
						     case "4":
						     $this->addExp($player, 1);
						     break;
						     case "14":
						     $this->addExp($player, 4);
						     break;
						     case "15":
						     $this->addExp($player, 4);
						     break;
						     case "16":
						     $this->addExp($player, 4);
						     break;
						     case "21":
						     $this->addExp($player, 5);
						     break;
						     case "59":
						     $this->addExp($player, 7);
						     break;
						     case "129":
						     $this->addExp($player, 10);
						     break;
						}
           if($this->getExp($player) >= $this->getNextExp($player)){
				  $this->setLevel($player, $this->getLevel($player) + 1);
	            $this->need[$player->getName()] == true;
						}
					}
				}
			}
	  public function onCommand(CommandSender $sender, Command $command, $label, array $args)	{
		      if($command->getName() == "givecup"){
                 if($sender->isOp()){
			             if(!isset($args[0])){
                   $sender->sendMessage("§e-------------------\n§e§oAward the trophy to the player!\n§l§c1.§b /givecup <player>§e - §6 Trao cúp cho người chơi.");
                 return true;
                   }
						$player = $this->getServer()->getPlayer($args[0]);
							if(!$player){
								$sender->sendMessage("Không tồn tại người chơi này!");
								return true;
								}
							if($this->getLevel($player) < 3){
								$item = Item::get(274, 0, 1);
									$item->setCustomName($this->getNamePickaxe($player));
									$item->setLore(array($this->getLorePickaxe($player)));
								} elseif($this->getLevel($player) >= 3 &&$this->getLevel($player) < 20){
									$item = Item::get(257, 0, 1);
									$item->setCustomName($this->getNamePickaxe($player));
									$item->setLore(array($this->getLorePickaxe($player)));
									} elseif($this->getLevel($player) >= 20){
										$item = Item::get(278, 0, 1);
										$item->setCustomName($this->getNamePickaxe($player));
										$item->setLore(array($this->getLorePickaxe($player)));
										}
										$player->getInventory()->addItem($item);
										$sender->sendMessage("§l§aTrao cúp thành công!");
					} else{
					   $sender->sendMessage("§l§cError!");
					}
				} else{
					$sender->sendMessage("§cKhông có quyền!");
				}						
				if($command->getName() == "topcup"){
					if(!isset($args[0])){
						$sender->sendMessage("§e----------------\n§l§b1.§a /topcup§e <level>§6 Hiển thị bảng xếp hạng cúp của người chơi.\n§b2.§a /topcup§e <break>§6 Hiển thị bảng xếp hạng số lượng phá khối của người chơi bằng cúp.\n\n\n§c§oKHÔNG CHỈNH SỬA DỮ LIỆU TRONG CONFIG.");
						return true;
						}
			    	if(!in_array($args[0], array("level", "break"))){
					  #
					  return true;
					}
					if($args[0] == "level"){
						$max = 0;
						foreach($this->level->getAll() as $c){
						    $max =+ count($c);
							}
					$page = ceil($max/5);
					$page = array_shift($args);
					$page = max(1, $page);
					$page = min($max, $page);
					$page = (int)$page;
					$sender->sendMessage("§6⎳§e Bảng xếp hạng§c Lv.Pickaxe:§f <§c".$page."§f/§c".$max."§f>");
					$aa = $this->level->getAll();
					arsort($aa);
					$i = 0;
					foreach($aa as $b => $a){
						if(($page - 1) * 5 <= $i && $i <= ($page - 1) * 5 + 4){
							$i1 = $i + 1;
							$c = $this->level->get($b)["Level"];
                    $equal = ($this->getExp($b)/$this->getNextExp($b))*100;
							$sender->sendMessage("§e→§c TOP§6 ".$i1."§4 ".$b.":§b Trình độ§9 ".$c."§f Kinh nghiệm:§e ".round($equal, 2)."%");
							}
							$i++;
						}
					}					
		if($args[0] == "break"){
			$max = 0;
				foreach($this->break->getAll() as $c){
						    $max =+ count($c);
							}
					$page = ceil($max/5);
					$page = array_shift($args);
					$page = max(1, $page);
					$page = min($max, $page);
					$page = (int)$page;
					$sender->sendMessage("§6⎳§e Bảng xếp hạng§c Break:§f <§c".$page."§f/§c".$max."§f>");
					$aa = $this->level->getAll();
					arsort($aa);
					$i = 0;
					foreach($aa as $b => $a){
						if(($page - 1) * 5 <= $i && $i <= ($page - 1) * 5 + 4){
							$i1 = $i + 1;
							$c = $this->break->get($b);
							$sender->sendMessage("§e→§c TOP§6 ".$i1."§4 ".$b.":§b Trình độ§9 ".$c);
							}
							$i++;									
			}
      }
  }
}
}